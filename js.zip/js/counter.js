window.addEventListener("click", function (event) {
  if (event.target.hasAttribute("data-action")) {
    // От кнопки, по которой кликнули, находим обертку текущего счетчика
    const counterWrapper = event.target.closest(".counter-wrapper");
    // От обертки счетчика находим div со значением счетчика
    const counter = counterWrapper.querySelector("[data-counter]");

    if (event.target.dataset.action === "plus") {
      // Изменяем текст в счетчике, увеличивая его на единицу
      counter.innerText = ++counter.innerText;

      if (event.target.closest(".cart-wrapper")) {
        // Пересчитывает стоимость товаров в корзине. Скрывает/ показывает лишние блоки
        toggleCartStatus();
      }
    } else if (event.target.dataset.action === "minus") {
      //  Проверка, где находится товар - в каталоге или корзине

      // Если товар в корзине, то уменьшаем до 1 и потом удаляем
      if (event.target.closest(".cart-wrapper")) {
        if (parseInt(counter.innerText) > 1) {
          // Если количество больше единицы, то уменьшаем на 1
          counter.innerText = --counter.innerText;
        }
        // Если количество = 1, то удаляем товар из корзины
        else {
          event.target.closest(".cart-item").remove();
        }
        // Пересчитывает стоимость товаров в корзине. Скрывает/ показывает лишние блоки
        toggleCartStatus();
      }
      // Если товар в каталоге, то уменьшаем до 1
      else {
        if (parseInt(counter.innerText) > 1) {
          // Изменяем текст в счетчике, уменьшая его на единицу
          counter.innerText = --counter.innerText;
        }
      }
    }
  }
});

/*
// Находим кнопку Плюс и Минус
const btnPlus = document.querySelector('[data-action="plus"]');
const btnMinus = document.querySelector('[data-action="minus"]');

// Слушаем клик по кнопке Плюс
btnPlus.addEventListener("click", function (event) {
  // От кнопки Плюс находим обертку текущего счетчика
  const counterWrapper = event.target.closest(".counter-wrapper");
  // От обертки счетчика находим div со значением счетчика
  const counter = counterWrapper.querySelector("[data-counter]");
  // Изменяем текст в счетчике, увеличивая его на единицу
  counter.innerText = ++counter.innerText;
});

// Слушаем клик по кнопке Минус
btnMinus.addEventListener("click", function (event) {
  // От кнопки Минус находим обертку текущего счетчика
  const counterWrapper = event.target.closest(".counter-wrapper");
  // От обертки счетчика находим div со значением счетчика
  const counter = counterWrapper.querySelector("[data-counter]");

  // Уменьшаем счетчик только до 1
  if (parseInt(counter.innerText) > 1) {
    // Изменяем текст в счетчике, уменьшая его на единицу
    counter.innerText = --counter.innerText;
  }
});
*/
